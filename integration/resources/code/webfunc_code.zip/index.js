const http = require('http');

const server = http.createServer((req, res) => {
  if (req.url === '/env') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    res.end(JSON.stringify(process.env));
  } else if (req.url === '/timeout') {
    const timeout = parseInt(process.env.TIMEOUT_MS || '0');
    setTimeout(() => {
      res.writeHead(200, {'Content-Type': 'text/plain'});
      res.end('completed');
    }, timeout);
  } else {
    res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('hello');
  }
});

server.listen(3000);
