exports.handler = function(e, c) {
    c.succeed("hello");
}
